# 📚 Online Bookstore Web Application

An interactive, responsive, multi-page Online Bookstore front-end created using **HTML5** and **CSS3**.

---

## 🌟 Features

- **Multi-Department Catalog**: Browse curated book selections organized by engineering streams (CSE, ECE, EEE, Civil).
- **Interactive Shopping Cart**: View selected titles, check pricing, and manage items.
- **User Authentication Pages**: Clean UI designs for User Login and Account Registration.
- **Frame-based Layout**: Structured multi-frame navigation with dedicated header, side menu, main content area, and home view.
- **Rich Visual Showcase**: High-resolution book covers tailored for technical streams.


---

## 📁 Project Structure

```text
.
├── home.html           # Main dashboard / landing page
├── frame.html          # Layout container framing header, menu, and main content
├── header.html         # Website header banner and logo section
├── menu.html           # Side navigation bar listing streams and categories
├── catalogue.html      # Central catalog view
├── cart.html           # Shopping cart interface
├── login.html          # User login page
├── registration.html   # User sign-up and registration form
├── cse.html            # CSE department book catalog
├── ece.html            # ECE department book catalog
├── eee.html            # EEE department book catalog
├── civil.html          # Civil engineering department book catalog
└── miniproject.html    # Project overview / meta details page